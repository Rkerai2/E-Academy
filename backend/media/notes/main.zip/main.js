import React from 'react';

const ServicesSection = () => {
  const services = [
    { name: 'Web Application', icon: '🌐' },
    { name: 'Scripting', icon: '📜' },
    { name: 'Desktop Applications', icon: '💻' },
    { name: 'API & Integrations', icon: '🔗' },
    { name: 'Bug Fixes', icon: '🐛' },
    { name: 'Help/Consult', icon: '🆘' }
  ];


  const service = [
  {
    id: 1,
    title: 'I will develop web application, web-based software and mobile app',
    rating: 4.9,
    reviews: 191,
    price: '₹131,455',
    level: 'Fiverr\'s Choice',
    imgSrc: 'path_to_image_1',  // Replace with actual image path
  },
  {
    id: 2,
    title: 'I will build custom bot software to automate any tasks',
    rating: 5.0,
    reviews: 23,
    price: '₹439',
    level: 'Level 1',
    imgSrc: 'path_to_image_2',  // Replace with actual image path
  },
  {
    id: 3,
    title: 'I will do python web scraping, data scraping and custom web scraper',
    rating: 5.0,
    reviews: 18,
    price: '₹439',
    level: 'Level 1',
    imgSrc: 'path_to_image_3',  // Replace with actual image path
  },
  {
    id: 4,
    title: 'I will build selenium and beautifulsoup parser and scraper',
    rating: 4.8,
    reviews: 22,
    price: '₹877',
    level: 'Level 2',
    imgSrc: 'path_to_image_4',  // Replace with actual image path
  }
];

const ServiceCard = ({ service }) => (
  <div className="bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300 p-4">
    <div className="relative">
      <img src={service.imgSrc} alt={service.title} className="w-full h-40 object-cover rounded-md" />
      <button className="absolute top-2 right-2 bg-white p-2 rounded-full shadow-md text-gray-600 hover:text-red-500">
        <i className="fa fa-heart"></i>
      </button>
    </div>
    <div className="py-4">
      <h3 className="text-lg font-semibold text-gray-800 mb-2">{service.title}</h3>
      <div className="flex items-center mb-2">
        <span className="text-yellow-500">
          <i className="fa fa-star"></i>
        </span>
        <span className="ml-1 text-sm text-gray-600">{service.rating}</span>
        <span className="ml-1 text-sm text-gray-500">({service.reviews} reviews)</span>
      </div>
      <div className="flex justify-between items-center">
        <span className="text-green-600 font-bold">{service.price}</span>
        <span className="px-2 py-1 bg-gray-100 text-sm rounded-full">{service.level}</span>
      </div>
    </div>
  </div>
);


  return (

    <>
    <div className="bg-white p-8">
      <div className="max-w-7xl mx-auto ml-10">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">Python Developers</h1>
        <p className="mb-6 text-gray-600">Create professional Python based web applications with the help of freelance Python experts</p>
        
        <div className="flex  no-scrollbar space-x-4 mb-6">
          {services.map((service, index) => (
            <div key={index} className="min-w-max h-26 bg-gray-100 rounded-3xl shadow px-4 py-2 flex items-center space-x-2">
              <span className="text-lg">{service.icon}</span>
              <span className="font-medium text-gray-700">{service.name}</span>
            </div>
          ))}
        </div>
        <hr/>
        <div className="flex space-x-4 mt-10">
          <button className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded inline-flex items-center">
            <span>Service options</span>
          </button>
          <button className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded inline-flex items-center">
            <span>Seller details</span>
          </button>
          <button className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded inline-flex items-center">
            <span>Budget</span>
          </button>
          <button className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded inline-flex items-center">
            <span>Delivery time</span>
          </button>
        
        </div>
      </div>
    </div>

    <div className="container mx-auto px-4 py-8">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {service.map(service => (
        <ServiceCard key={service.id} service={service} />
      ))}
     </div>
    </div>



    </>
  );
};

export default ServicesSection;
